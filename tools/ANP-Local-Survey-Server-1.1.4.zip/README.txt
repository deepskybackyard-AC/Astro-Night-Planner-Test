ANP Local Survey Server 1.1 – Build 1.1.4
================================================

Windows-Hilfsprogramm für lokale HiPS-Surveys des Astro Night Planners.
Der Dateiname ANP-Local-Survey-Server.exe bleibt bei Updates unverändert.
Die Version wird in der Browseroberfläche angezeigt.

Start
-----
1. ZIP vollständig in einen eigenen Ordner entpacken.
2. ANP-Local-Survey-Server.exe doppelklicken.
3. Die Browseroberfläche öffnet sich automatisch. Das Tray-Symbol bleibt aktiv.
4. Über das Tray-Kontextmenü können Oberfläche, Serverstart, Serverstopp und
   Beenden gesteuert werden.

Wichtig beim Austausch
----------------------
Die alte EXE vorher im Tray-Menü mit „Beenden“ vollständig schließen. Danach
ANP-Local-Survey-Server.exe ersetzen. Der unveränderte Dateiname erhält
Verknüpfungen und Autostart-Einträge.

Downloadverwaltung
------------------
- Alle 15 in Astro Night Planner eingebauten Surveys sind mit geprüften
  Dienstadressen vorbelegt.
- Der Download prüft properties und Moc.fits.
- Die benötigten HiPS-Kacheln werden aus der MOC-Abdeckung ermittelt; ein
  Verzeichnislisting des Webservers ist nicht erforderlich.
- Vorhandene Dateien werden übersprungen, .part-Dateien werden fortgesetzt.
- Quelle und relativer Zielpfad können pro Survey gespeichert werden.
- Der vollständig aufgelöste lokale Zielpfad wird angezeigt.
- Große Surveys können viele Gigabyte oder mehrere hundert Gigabyte benötigen.

Pfade
-----
Survey-Hauptordner (Beispiel):
  F:\AstroSurveys
Relativer Zielpfad (Beispiel):
  nsns/halpha8/
Vollständiger lokaler Zielpfad:
  F:\AstroSurveys\nsns\halpha8\

Die Mischung ist korrekt: absolute Windows-Pfade verwenden Backslashes,
relative HiPS-Pfade Forward-Slashes. Der Server normalisiert beide Formen.
