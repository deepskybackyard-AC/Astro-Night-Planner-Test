ANP Local Survey Server 1.1 – Build 1.1.4
================================================

Windows helper for local HiPS surveys used by Astro Night Planner.
The executable name ANP-Local-Survey-Server.exe remains unchanged across
updates. The version is shown in the browser interface.

Start
-----
1. Extract the complete ZIP into its own folder.
2. Double-click ANP-Local-Survey-Server.exe.
3. The browser interface opens automatically and the tray icon remains active.
4. The tray menu opens the interface, starts/stops the survey server and exits.

Replacing an older build
------------------------
Exit the old program completely from its tray menu before replacing the EXE.
The stable filename preserves shortcuts and Windows autostart entries.

Download manager
----------------
- All 15 surveys built into Astro Night Planner have verified default service URLs.
- The downloader checks properties and Moc.fits.
- Required tiles are derived from the MOC coverage map; a web directory listing
  is not required.
- Existing files are skipped and .part files are resumed.
- Source URL and relative target path can be saved per survey.
- The resolved local target path is shown.
- Large surveys may require many or hundreds of gigabytes.
