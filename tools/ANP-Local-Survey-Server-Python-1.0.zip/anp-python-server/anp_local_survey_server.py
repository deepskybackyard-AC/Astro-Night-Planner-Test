#!/usr/bin/env python3
"""
ANP Local Survey Server - Python edition
Version: 1.0

Serves a local HiPS survey root folder over HTTP for Astro Night Planner.
The folder is accessed by the browser via http://127.0.0.1:8765/ instead of a local file path.

Example:
  python3 anp_local_survey_server.py --root /home/user/AstroSurveys
  python3 anp_local_survey_server.py --root /home/user/AstroSurveys --port 8765 --open

Folder example:
  /home/user/AstroSurveys/nsns/ohs8/properties
  /home/user/AstroSurveys/nsns/ohs8/Norder4/Dir0/Npix123.png

Astro Night Planner settings:
  Local survey base URL: http://127.0.0.1:8765/
  Relative survey path:  nsns/ohs8/
"""

from __future__ import annotations

import argparse
import os
import posixpath
import sys
import threading
import time
import webbrowser
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional
import mimetypes

VERSION = "1.0"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765

# HiPS-related MIME types. The defaults are usually enough for PNG/JPEG,
# but these additions make properties/FITS/MOC handling clearer.
mimetypes.add_type("text/plain", ".properties")
mimetypes.add_type("text/plain", ".txt")
mimetypes.add_type("application/fits", ".fits")
mimetypes.add_type("application/fits", ".fit")
mimetypes.add_type("application/fits", ".fts")
mimetypes.add_type("application/octet-stream", ".moc")


class ANPSurveyHandler(SimpleHTTPRequestHandler):
    """Static file handler with CORS headers for local HiPS access."""

    server_version = f"ANPLocalSurveyServer/{VERSION}"

    def end_headers(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Cross-Origin-Resource-Policy", "cross-origin")
        super().end_headers()

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self.end_headers()

    def log_message(self, fmt: str, *args: object) -> None:
        if getattr(self.server, "quiet", False):
            return
        super().log_message(fmt, *args)

    def guess_type(self, path: str) -> str:
        # HiPS properties files are often named exactly "properties" without suffix.
        base = posixpath.basename(path)
        if base == "properties":
            return "text/plain; charset=utf-8"
        return super().guess_type(path)


def validate_root(root: Path) -> Path:
    root = root.expanduser().resolve()
    if not root.exists():
        raise SystemExit(f"Root folder does not exist: {root}")
    if not root.is_dir():
        raise SystemExit(f"Root path is not a folder: {root}")
    return root


def find_example_properties(root: Path) -> Optional[Path]:
    # Look for a typical HiPS properties file without scanning too deeply.
    common = [
        root / "nsns" / "ohs8" / "properties",
        root / "nsns" / "halpha8" / "properties",
        root / "nsns" / "oiii8" / "properties",
        root / "nsns" / "sii8" / "properties",
        root / "nsns" / "hbr8" / "properties",
        root / "nsns" / "rgb8" / "properties",
    ]
    for item in common:
        if item.is_file():
            return item
    for item in root.rglob("properties"):
        if item.is_file():
            return item
    return None


def open_browser_later(url: str, delay: float = 0.8) -> None:
    def _open() -> None:
        time.sleep(delay)
        try:
            webbrowser.open(url)
        except Exception:
            pass

    threading.Thread(target=_open, daemon=True).start()


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Serve a local HiPS survey root folder for Astro Night Planner."
    )
    parser.add_argument(
        "--root",
        "-r",
        default=".",
        help="Survey root folder. Example: /home/user/AstroSurveys or D:\\AstroSurveys. Default: current folder.",
    )
    parser.add_argument(
        "--host",
        default=DEFAULT_HOST,
        help=f"Bind address. Default: {DEFAULT_HOST}. Use 0.0.0.0 only if other devices in your LAN should access it.",
    )
    parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=DEFAULT_PORT,
        help=f"HTTP port. Default: {DEFAULT_PORT}.",
    )
    parser.add_argument(
        "--open",
        action="store_true",
        help="Open the local base URL in the default browser after startup.",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Reduce request logging.",
    )
    return parser


def main(argv: list[str]) -> int:
    args = build_arg_parser().parse_args(argv)
    root = validate_root(Path(args.root))

    handler_class = lambda *handler_args, **handler_kwargs: ANPSurveyHandler(  # noqa: E731
        *handler_args, directory=str(root), **handler_kwargs
    )

    try:
        httpd = ThreadingHTTPServer((args.host, args.port), handler_class)
    except OSError as exc:
        print(f"Cannot start server on {args.host}:{args.port}: {exc}", file=sys.stderr)
        print("Try another port, for example: --port 8766", file=sys.stderr)
        return 2

    httpd.quiet = bool(args.quiet)  # type: ignore[attr-defined]

    base_url = f"http://{args.host if args.host != '0.0.0.0' else '127.0.0.1'}:{args.port}/"
    print(f"ANP Local Survey Server - Python edition {VERSION}")
    print(f"Survey root folder: {root}")
    print(f"Local base URL for Astro Night Planner: {base_url}")

    example = find_example_properties(root)
    if example:
        rel = example.parent.relative_to(root).as_posix() + "/"
        print(f"Example relative survey path: {rel}")
        print(f"Example properties URL: {base_url}{rel}properties")
    else:
        print("No HiPS 'properties' file found in common folders yet.")
        print("Expected example: <root>/nsns/ohs8/properties")

    print("Press Ctrl+C to stop the server.")
    print()

    if args.open:
        open_browser_later(base_url)

    try:
        httpd.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\nStopping server ...")
    finally:
        httpd.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
