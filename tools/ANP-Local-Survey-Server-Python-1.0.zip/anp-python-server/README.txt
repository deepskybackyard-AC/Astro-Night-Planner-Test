ANP Local Survey Server - Python edition 1.0
===========================================

This is a small cross-platform helper for Astro Night Planner.
It serves a local HiPS survey root folder via HTTP.

Typical Astro Night Planner settings:

  Local survey base URL: http://127.0.0.1:8765/
  Relative path:          nsns/ohs8/

Example folder structure:

  AstroSurveys/
    nsns/
      ohs8/
        properties
        Norder0/
        Norder1/
        ...
      halpha8/
      oiii8/
      sii8/

Linux example:

  cd ~/Downloads/anp-python-server
  python3 anp_local_survey_server.py --root ~/AstroSurveys --port 8765 --open

macOS example:

  cd ~/Downloads/anp-python-server
  python3 anp_local_survey_server.py --root ~/AstroSurveys --port 8765 --open

Windows example:

  py -3 anp_local_survey_server.py --root D:\AstroSurveys --port 8765 --open

Stop the server:

  Press Ctrl+C in the terminal window.

Notes:

- Keep the terminal open while you use local surveys.
- Use 127.0.0.1 for local-only access.
- Use --host 0.0.0.0 only if other devices in your LAN should access the survey server.
- If port 8765 is already in use, choose another port and enter the matching base URL in Astro Night Planner.
