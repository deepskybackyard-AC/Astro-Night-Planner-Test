@echo off
REM Adjust the path after --root to your survey root folder.
py -3 "%~dp0anp_local_survey_server.py" --root "%USERPROFILE%\AstroSurveys" --port 8765 --open
pause
