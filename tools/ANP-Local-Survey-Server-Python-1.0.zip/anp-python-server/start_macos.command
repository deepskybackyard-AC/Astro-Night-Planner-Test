#!/usr/bin/env bash
# Adjust the path after --root to your survey root folder.
cd "$(dirname "$0")"
python3 anp_local_survey_server.py --root "$HOME/AstroSurveys" --port 8765 --open
