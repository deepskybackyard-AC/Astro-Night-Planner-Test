#!/usr/bin/env bash
# Adjust the path after --root to your survey root folder.
python3 "$(dirname "$0")/anp_local_survey_server.py" --root "$HOME/AstroSurveys" --port 8765 --open
