ANP Local Survey Server 1.1 - Build 1.1.5
================================================

Windows-Hilfsprogramm fuer lokale HiPS-Surveys des Astro Night Planners.
Der Dateiname ANP-Local-Survey-Server.exe bleibt bei Updates unveraendert.
Die Version wird in der Browseroberflaeche angezeigt.

Start
-----
1. ZIP vollstaendig in einen eigenen Ordner entpacken.
2. ANP-Local-Survey-Server.exe doppelklicken.
3. Die Browseroberflaeche oeffnet sich automatisch. Das Tray-Symbol bleibt aktiv.
4. Ueber das Tray-Kontextmenue koennen Oberflaeche, Serverstart, Serverstopp und
   Beenden gesteuert werden.

Wichtig beim Austausch
----------------------
Die alte EXE vorher im Tray-Menue mit "Beenden" vollstaendig schliessen. Danach
ANP-Local-Survey-Server.exe ersetzen. Der unveraenderte Dateiname erhaelt
Verknuepfungen und Autostart-Eintraege.

Robuste Downloads in Build 1.1.5
--------------------------------
- Temporäre Netzwerkfehler, Verbindungsabbrueche, Timeouts sowie HTTP 429/5xx
  werden pro Datei automatisch mehrfach wiederholt.
- Die Wartezeit steigt schrittweise an; .part-Dateien werden weiterverwendet.
- Ein einzelner Fehler beendet nicht mehr den gesamten Download.
- Nach dem normalen Durchlauf folgt automatisch ein weiterer Wiederholungsdurchlauf.
- Fuer www.simg.de werden nur zwei parallele Verbindungen verwendet; fuer andere
  Quellen standardmaessig vier.
- Erst wenn Dateien auch nach allen Versuchen fehlen, wird der Lauf als
  unvollstaendig markiert. Ein erneutes Starten ueberspringt fertige Dateien.

Tray-Stabilitaet in Build 1.1.5
-------------------------------
- Der Windows-Nachrichtenloop laeuft dauerhaft auf einem festen UI-Thread.
- Rechtsklick und Doppelklick werden auch mit aktuellen Windows-Tray-Ereignissen
  verarbeitet.
- Nach einem Neustart des Windows-Explorers wird das Tray-Symbol neu angelegt.
- Das Programm prueft regelmaessig, ob das Tray-Symbol noch registriert ist.
- "Beenden" besitzt eine Sicherheitsabschaltung, damit die EXE notfalls ohne
  Task-Manager freigegeben wird.

Downloadverwaltung
------------------
- Alle 15 in Astro Night Planner eingebauten Surveys sind mit geprueften
  Dienstadressen vorbelegt.
- Der Download prueft properties und Moc.fits.
- Die benoetigten HiPS-Kacheln werden aus der MOC-Abdeckung ermittelt; ein
  Verzeichnislisting des Webservers ist nicht erforderlich.
- Vorhandene Dateien werden uebersprungen, .part-Dateien werden fortgesetzt.
- Quelle und relativer Zielpfad koennen pro Survey gespeichert werden.
- Der vollstaendig aufgeloeste lokale Zielpfad wird angezeigt.
- Grosse Surveys koennen viele Gigabyte oder mehrere hundert Gigabyte benoetigen.

Pfade
-----
Survey-Hauptordner (Beispiel):
  F:\AstroSurveys
Relativer Zielpfad (Beispiel):
  nsns/halpha8/
Vollstaendiger lokaler Zielpfad:
  F:\AstroSurveys\nsns\halpha8\

Die Mischung ist korrekt: absolute Windows-Pfade verwenden Backslashes,
relative HiPS-Pfade Forward-Slashes. Der Server normalisiert beide Formen.
