ANP Local Survey Server 1.1 - Build 1.1.5
================================================

Windows helper for local HiPS surveys used by Astro Night Planner.
The executable name ANP-Local-Survey-Server.exe remains unchanged across
updates. The version is shown in the browser interface.

Start
-----
1. Extract the complete ZIP into its own folder.
2. Double-click ANP-Local-Survey-Server.exe.
3. The browser interface opens automatically and the tray icon remains active.
4. The tray menu opens the interface, starts/stops the survey server and exits.

Replacing an older build
------------------------
Exit the old program completely from its tray menu before replacing the EXE.
The stable filename preserves shortcuts and Windows autostart entries.

Robust downloads in build 1.1.5
-------------------------------
- Temporary network errors, closed connections, timeouts and HTTP 429/5xx are
  retried automatically for each file.
- Retry delays increase gradually and existing .part files are reused.
- One failed tile no longer stops the complete download.
- A final automatic recovery pass retries files still missing after the main pass.
- Downloads from www.simg.de use only two parallel connections; other sources use
  four by default.
- The run is marked incomplete only when files still fail after every retry.

Tray reliability in build 1.1.5
-------------------------------
- The Windows message loop stays on a dedicated UI thread.
- Right-click and double-click handle current Windows tray notifications.
- The tray icon is restored after Windows Explorer restarts.
- The program periodically checks that the tray icon remains registered.
- Exit has a safety fallback so the EXE can be replaced without Task Manager.

Download manager
----------------
- All 15 surveys built into Astro Night Planner have verified default service URLs.
- The downloader checks properties and Moc.fits.
- Required tiles are derived from the MOC coverage map; a web directory listing
  is not required.
- Existing files are skipped and .part files are resumed.
- Source URL and relative target path can be saved per survey.
- The resolved local target path is shown.
- Large surveys may require many or hundreds of gigabytes.
