ANP Local Survey Server 1.1.3 - Windows
=======================================

Das Programm stellt lokale HiPS-Surveys fuer den Astro Night Planner bereit.

Start und Bedienung
-------------------
1. ZIP vollstaendig entpacken.
2. ANP-Local-Survey-Server-1.1.3.exe per Doppelklick starten.
3. Die Browseroberflaeche wird automatisch geoeffnet. Das Programm bleibt im
   Windows-Infobereich (Tray) aktiv.
4. Survey-Hauptordner waehlen, Konfiguration speichern und den Survey-Server starten.

Tray und Beenden
----------------
- Doppelklick auf das Tray-Symbol oeffnet die Browseroberflaeche.
- Rechtsklick zeigt: Oberflaeche oeffnen, Server starten, Server stoppen, Beenden.
- "Server stoppen" beendet nur den Survey-Dateiserver; die Konfigurationsoberflaeche
  und das Tray bleiben aktiv.
- "Beenden / Exit" beendet das Programm vollstaendig und gibt die EXE frei.
- Wird das Browserfenster geschlossen, laufen Server und Tray weiter.

Ordnerauswahl
-------------
Die Ordnerdialoge werden direkt auf dem Windows-UI-Thread geoeffnet. Dadurch
erscheinen sie zuverlaessig vor dem Browser und benoetigen weder PowerShell noch
einen PATH-Eintrag. Verwendet werden sie fuer Survey-Hauptordner und Downloadziel.

Survey-Downloads
----------------
Die Downloadliste enthaelt alle in Astro Night Planner eingebauten Surveys mit
vorbelegten HiPS-Quelladressen:
- DSS2 Farbe, DSS2 red, DSS2 Blau
- PanSTARRS DR1 Farbe
- VTSS H-alpha, Finkbeiner H-alpha
- WISE, 2MASS, IRIS
- alle sechs NSNS-DR0.2-Surveys
- zusaetzlich benutzerdefinierte HiPS-Surveys

Funktionen: Start, Pause, Fortsetzen, Abbrechen, Wiederaufnahme vorhandener
.part-Dateien, Ueberspringen vollstaendiger Dateien und Pruefung lokaler Daten.
Ein vollstaendiger Download ist nur moeglich, wenn der Quellserver die benoetigte
Ordnerstruktur bereitstellt und der Download technisch sowie rechtlich zulaessig ist.
Sehr grosse Surveys koennen erheblichen Speicherplatz benoetigen.

Konfigurationsuebernahme
------------------------
Beim ersten Start sucht Version 1.1.3 nach der bisherigen Datei
ANP-Local-Survey-Server-config.json im Programmordner, aktuellen Ordner,
Benutzerordner und AppData. Gefundene Einstellungen werden uebernommen; die alte
Datei bleibt erhalten.

Planner-Konfiguration
---------------------
Lokale Survey-Basis-URL: http://127.0.0.1:8765/
Beispiel relativer Pfad: nsns/ohs8/
Pruefadresse: http://127.0.0.1:8765/nsns/ohs8/properties

English summary
---------------
Double-click the EXE. The browser interface opens automatically and the program
continues in the Windows notification area. The native folder picker is opened
on the Windows UI thread and does not require PowerShell. The tray menu can open
the interface, start/stop the survey file server, or exit the program completely.
All surveys built into Astro Night Planner are listed with default HiPS source URLs,
and custom HiPS surveys can also be configured.
